class A{
    static void show(){
        System.out.println("I am the Show ");
    }
    public static void main(String[] args) {
        A.show();
        hgdfkjhgkdfj
    }
}