const childProcess = require('child_process');
const buffer = childProcess.execSync("javac /Users/amitsrivastava/Documents/projects/pizza-app/codeeditor/A.java");
console.log(buffer.toString());