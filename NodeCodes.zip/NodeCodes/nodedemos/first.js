var a = 100;
var b  =200;
var c = a + b;
console.log('Sum is ',c);