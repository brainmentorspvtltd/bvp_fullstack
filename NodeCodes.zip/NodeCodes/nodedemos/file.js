const fs = require('fs');
console.log('typeof ',typeof fs);
console.log('Before Read...');
const path = '/Users/amit/Documents/bvp-fullstack/nodedemos/first.js';
fs.readFile(path,(err,content)=>{
    if(err){
        console.log('Error in Reading ',err);
    }
    else{
        console.log('1. Data is '+content);
    }
});
fs.readFile(path,(err,content)=>{
    if(err){
        console.log('Error in Reading ',err);
    }
    else{
        console.log('2. Data is '+content);
    }
});
fs.readFile(path,(err,content)=>{
    if(err){
        console.log('Error in Reading ',err);
    }
    else{
        console.log('3. Data is '+content);
    }
})
console.log('After Read...');