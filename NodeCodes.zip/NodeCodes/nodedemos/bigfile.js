const fs = require('fs');
const path = '/Users/amit/Documents/flutter-recording/ShoppingStartTicTacLogic.mov';
const path2 = '/Users/amit/Documents/flutter-recording/ShoppingStartTicTacLogicClone.mov';
console.log('Before Read');
// fs.readFile(path,(err,content)=>{
//     if(err){
//         console.log('Error in File Read ',err);
//     }
//     else{
//         console.log('Data is ',content);
//     }
// });
const stream = fs.createReadStream(path,{highWaterMark:20});
const wstream = fs.createWriteStream(path2,{highWaterMark:20});
console.log('After Read .... ');
stream.pipe(wstream);
console.log('After Pipe Copy Done');
/*stream.on('data',chunk=>{
    console.log('Chunk is ',chunk);
    wstream.write(chunk);
});
stream.on('end',()=>{
    console.log('Stream is End COPY IS DONE');
})*/