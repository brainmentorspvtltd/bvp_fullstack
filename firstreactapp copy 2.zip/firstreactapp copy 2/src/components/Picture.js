import React from 'react';
export const Picture = (props)=>{
    return (<img src={props.url} alt="Image is Missing"/>);
}