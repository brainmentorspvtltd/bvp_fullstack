import logo from './logo.svg';
import './App.css';
import { Product } from './modules/products/presentations/pages/Products';

function App() {
  return (
    <Product/>
  );
}

export default App;
