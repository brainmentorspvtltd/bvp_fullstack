import PrimarySearchAppBar from "../../../../shared/widgets/AppBar";
import HeaderMenu from "../../../../shared/widgets/HeaderMenu";
import Container from '@mui/material/Container';
import { API_CLIENT } from "../../../../shared/services/api-client";
import { useEffect, useState } from "react";
import Item from "../components/Item";
export const Product = ()=>{
    const [products, setProducts]=useState([]);
    const loadDefault = async ()=>{
        const URL = process.env.REACT_APP_GET_PRODUCT+"?type=Pizza";
        //const URL  = 'http://localhost:7777/get-product?type=Pizza';
        const r = fetch(URL).then(r=>r.json()).catch(err=>console.log('Error !!!! ',err));
        console.log(r);
        r.then(d=>setProducts(d.products)).catch(e=>console.log('QQQQ ',e));
        // const result =  await API_CLIENT.get(URL,'Pizza');
        // console.log('###Result ',result, 'URL ',URL);
        //setProducts(result.data);
    }
    useEffect(()=>{
            loadDefault();
       
    },[]);
    const getItem = async (itemName)=>{
        console.log('Item Name :::: ',itemName);
        const URL = process.env.REACT_APP_GET_PRODUCT+"?type="+itemName;
        //const URL  = 'http://localhost:7777/get-product?type=Pizza';
        const r = fetch(URL).then(r=>r.json()).catch(err=>console.log('Error !!!! ',err));
        console.log(r);
        r.then(d=>setProducts(d.products)).catch(e=>console.log('QQQQ ',e));
        // try{
        // // const result = await API_CLIENT.get(URL,itemName);
        // // console.log('####Result ',result, 'URL ',URL);
        // // setProducts(result.data);
        // }
        // catch(err){
        //     console.log('Inside Catch ',err);
        // }
       
    }
    return (
        <Container fixed>
    <PrimarySearchAppBar/>
    <HeaderMenu getItem = {getItem}/>
    {products.map((product,index)=><Item product={product} key={index}/>)}
    </Container>);
}