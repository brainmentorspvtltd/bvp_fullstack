import axios from 'axios';
export const API_CLIENT = {
    async get(URL, type){
        console.log(URL , type);
        //URL = 'http://localhost:7777/get-product?type=Pizza';
        const  r = await axios.get(URL);
        return r;
        //await  axios.get(URL,{headers:{"Content-Type": "application/json"}});
        //return await  axios.get(URL,{params:{type:type},headers:{"Content-Type": "application/json"}});
    }
}