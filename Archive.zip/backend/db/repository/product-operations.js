const ProductModel = require('../models/product-schema');
module.exports = {
    async add(productObject){
        const doc = await ProductModel.create(productObject);
        return doc;
    },
    async find(name){
        const docs = await ProductModel.find({name:name}).exec();
        console.log('DOCS ',docs);
        return docs;
    }
}